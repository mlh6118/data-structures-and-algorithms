
class BinaryTree():
  def __init__(self, root = None):
    self.root = root

  