
class Node:
  def __init__(self, value = None, next = None, left = None, right = None):
    self.next = next
    self.value = value
    self.left = left
    self.right = right
